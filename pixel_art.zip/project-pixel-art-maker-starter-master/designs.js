//store table element in variable.
const table = document.querySelector("#pixelCanvas");

function makeGrid() {
// Your code goes here!
// Select size input
const height = document.querySelector("#inputHeight").value;
const width = document.querySelector("#inputWidth").value;
// create tr and td element and store them in variables.    
    var row;
    var col;
// use for loop to add row and col in the table
    for(var i = 1; i <= height; i++) {
    // add tr element in table
        row = document.createElement('tr');
        table.appendChild(row);
        for(var j = 1; j <= width; j++) { 
            // add td element in tr 
            col = document.createElement('td');
            table.lastElementChild.appendChild(col);
        }
    }
}


// add event listener to change the backgroundcolor
table.addEventListener('click', function(evt) {
    // Select color input
    const color = document.querySelector("#colorPicker").value;
    //when click td element, reset element's color.
    if(evt.target.nodeName = "TD") {
        evt.target.style.backgroundColor = color;
    }
});

// When size is submitted by the user, call makeGrid()
document.addEventListener('submit', function(event) {
    // after submit, clear the old table.
    table.innerHTML = "";
    event.preventDefault();
    makeGrid();
});
